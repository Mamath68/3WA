# Cours de JS avancé

## Planning

Jour 1 : Syntaxe de base, manipulation du DOM
Jour 2 : Fonctionnalités avancées (fonctions fléchées, fonctions tableaux, déstructuration, import/export), programmation orientée objet, api HTML5 (géolocalisation, canvas)
Jour 3 : AJAX et api REST
Jour 4 : Promesses et async/await
Jour 5 : Projet

## Programme

* Cours le matin, travaux pratique l'après-midi, correction en fin de journée
* Dernier jour projet évalué (rendu : dépôt github/code sur l'ide en ligne)

## Horaires

9h30-12h30 (environ) avec une pause vers 11h
13h30-17h30 (environ) avec une pause vers 15h