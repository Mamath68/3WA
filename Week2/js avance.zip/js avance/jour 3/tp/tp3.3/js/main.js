const addressText = document.querySelector('#address');

document.querySelector('#get-location').addEventListener('click', () => {
    navigator.geolocation.getCurrentPosition(position => {
        // La position a été récupérée, on peut récupérer l'adresse de l'utilisateur
        const {latitude, longitude} = position.coords;
        
        fetch(`https://api-adresse.data.gouv.fr/reverse/?lon=${longitude}&lat=${latitude}`)
            .then(response => response.json())
            .then(response => {
                addressText.textContent = response.features[0].properties.label;
            });
    });
});