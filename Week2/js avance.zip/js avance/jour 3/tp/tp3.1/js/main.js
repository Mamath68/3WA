const baseUrl = "https://kaamelott.reiter.tf";
const randomQuote = document.querySelector('#random-quote p');
const randomQuoteAuthor = document.querySelector('#random-quote footer');

document.querySelector('#get-random-quote').addEventListener('click', (e) => {
    fetch(`${baseUrl}/quote/random`).then(response => response.json()).then(response => {
        randomQuote.textContent = response.citation;
        randomQuoteAuthor.textContent = response.infos.personnage;
    });
});