# API REST

## Définition

C'est une interface mise en place par un service en ligne (par exemple une plateforme qui donne des informations sur les films et séries). Cette interface est généralement composée de plusieurs url qui vont renvoyer des données.

Il existe de nombreuses API :
* API de cartographie (gmaps, mapbox...)
* API de l'état (la bonne alternance, découpage administratif, adresse...)
* API de jeux vidéos
* API de réseaux sociaux
* API de transports en commun (horaires tram/métro/train en temps réel, api blablacar...) 

[Liste d'API](https://github.com/public-apis/public-apis)

## Structure

Les API sont souvent structurées d'une manière similaire :
* base url (la partie commune à toutes les url pour une api)
* endpoint (points d'entrée)
* paramètres

### Exemple

Un exemple avec l'API découpage administratif du gouvernement :
* base url : https://geo.api.gouv.fr
* endpoint : 
  * /departements
  * /regions/{code}/departements
  * /departements/{code}
* paramètres :
  * limit
  * ...

Récupération de 5 départements : https://geo.api.gouv.fr/departements?limit=5