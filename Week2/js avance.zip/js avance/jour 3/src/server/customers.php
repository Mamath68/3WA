<?php

$pdo = new PDO(
    'mysql:host=db.3wa.io;dbname=cedricleclinche_classicmodels;charset=UTF8', 
    'cedricleclinche', 
    'eb094434df8b9e10f67b5c650f7bed6c', [
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]
);

$query = $pdo->prepare('SELECT * FROM customers');
$query->execute();

$customers = $query->fetchAll();

// Envoi des données brute => on va transformer ces données dans un format textuel
// Sérialisation au format JSON
$customersJson = json_encode($customers);

header('Content-Type: application/json');
echo $customersJson;
exit();

// Envoi des données sous forme de html
// require 'customers.phtml';