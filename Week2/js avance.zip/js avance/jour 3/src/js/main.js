const departmentList = document.querySelector('#department-list');

document.querySelector('#get-departments').addEventListener('click', (e) => {
    const url = 'https://geo.api.gouv.fr/departements';
    
    fetch(url).then(response => response.json()).then(response => {
        departmentList.innerHTML = response.map(department => {
            return `<li>${department.nom}</li>`;
        }).join('');
    });
});