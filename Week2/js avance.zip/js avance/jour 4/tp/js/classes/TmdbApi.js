class TmdbApi {
    #token;
    #baseUrl;
    
    constructor(token) {
        this.#token = token;
        this.#baseUrl = 'https://api.themoviedb.org/3';
    }
    
    searchMovies(search, page = 1) {
        const options = {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: 'Bearer ' + this.token
            }
        };
        
        const params = {
            query: search,
            language: "fr-FR",
            page: page
        };
        
        const urlParams = new URLSearchParams(params);
    
        return fetch(`${this.#baseUrl}/search/movie?${urlParams}`, options)
            .then(response => response.json());
    }
    
    get token() {
        return this.#token;
    }
    
    set token(token) {
        this.#token = token;
    }
}

export default TmdbApi;