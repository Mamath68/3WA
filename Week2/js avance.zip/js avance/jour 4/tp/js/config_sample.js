export const config = {
    token: 'Mettre votre propre token ici'
};