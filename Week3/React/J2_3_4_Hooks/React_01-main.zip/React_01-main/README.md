# Notes de cours

## Organisation

- React
    - semaine01
    - semaine02

- Dossiers React/semaine01/J1_introduction/

- Clonner le repo pour avoir les solutions des exercices

- Corrections
    - clone ... du repo