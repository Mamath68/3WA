

let a = 1.5

function calcul(){

    a = "bonjour";
}

calcul();

// effet de bord
console.log(a * 100)